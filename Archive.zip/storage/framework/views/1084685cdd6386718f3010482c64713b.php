<div <?php echo e($attributes->merge($getExtraAttributes())); ?>>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH /Users/robithrivaldy/filament-tutorial/vendor/filament/forms/src/../resources/views/components/grid.blade.php ENDPATH**/ ?>